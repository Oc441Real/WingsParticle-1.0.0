<?php

declare(strict_types = 1);

namespace Oc441\WingsParticle\libs\jojoe77777\FormAPI;

use pocketmine\plugin\PluginBase;

class FormAPI extends PluginBase{

}
